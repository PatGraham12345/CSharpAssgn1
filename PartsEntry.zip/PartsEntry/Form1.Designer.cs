﻿
namespace assignment2
{
    partial class PartsEntry
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(PartsEntry));
            this.submitButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.clearButton = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.partNumberTextBox = new System.Windows.Forms.TextBox();
            this.partDescriptionTextBox = new System.Windows.Forms.TextBox();
            this.itemClassTextBox = new System.Windows.Forms.TextBox();
            this.unitsOnHandTextBox = new System.Windows.Forms.TextBox();
            this.unitCostTextBox = new System.Windows.Forms.TextBox();
            this.totalInventoryCostTextBox = new System.Windows.Forms.TextBox();
            this.dailyUsageTextBox = new System.Windows.Forms.TextBox();
            this.yearlyUsageTextBox = new System.Windows.Forms.TextBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // submitButton
            // 
            this.submitButton.Location = new System.Drawing.Point(101, 379);
            this.submitButton.Name = "submitButton";
            this.submitButton.Size = new System.Drawing.Size(132, 40);
            this.submitButton.TabIndex = 9;
            this.submitButton.Text = "Submit";
            this.submitButton.UseVisualStyleBackColor = true;
            this.submitButton.Click += new System.EventHandler(this.submitButton_Click);
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(525, 379);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(132, 40);
            this.exitButton.TabIndex = 11;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // clearButton
            // 
            this.clearButton.Location = new System.Drawing.Point(317, 379);
            this.clearButton.Name = "clearButton";
            this.clearButton.Size = new System.Drawing.Size(132, 40);
            this.clearButton.TabIndex = 10;
            this.clearButton.Text = "Clear";
            this.clearButton.UseVisualStyleBackColor = true;
            this.clearButton.Click += new System.EventHandler(this.clearButton_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(101, 28);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(88, 17);
            this.label1.TabIndex = 3;
            this.label1.Text = "Part Number";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(101, 70);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(109, 17);
            this.label2.TabIndex = 4;
            this.label2.Text = "Part Description";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(101, 115);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(72, 17);
            this.label3.TabIndex = 5;
            this.label3.Text = "Item Class";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(101, 156);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(101, 17);
            this.label4.TabIndex = 6;
            this.label4.Text = "Units On Hand";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(101, 199);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(69, 17);
            this.label5.TabIndex = 7;
            this.label5.Text = "Unit Price";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(101, 243);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(134, 17);
            this.label6.TabIndex = 8;
            this.label6.Text = "Total Inventory Cost";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(101, 286);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(84, 17);
            this.label7.TabIndex = 9;
            this.label7.Text = "Daily Usage";
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(101, 331);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(93, 17);
            this.label8.TabIndex = 10;
            this.label8.Text = "Yearly Usage";
            this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // partNumberTextBox
            // 
            this.partNumberTextBox.Location = new System.Drawing.Point(275, 25);
            this.partNumberTextBox.Name = "partNumberTextBox";
            this.partNumberTextBox.Size = new System.Drawing.Size(100, 22);
            this.partNumberTextBox.TabIndex = 1;
            this.partNumberTextBox.Leave += new System.EventHandler(this.partNumberTextBox_Leave);
            // 
            // partDescriptionTextBox
            // 
            this.partDescriptionTextBox.Location = new System.Drawing.Point(275, 67);
            this.partDescriptionTextBox.Name = "partDescriptionTextBox";
            this.partDescriptionTextBox.Size = new System.Drawing.Size(100, 22);
            this.partDescriptionTextBox.TabIndex = 2;
            this.partDescriptionTextBox.Leave += new System.EventHandler(this.partDescriptionTextBox_Leave);
            // 
            // itemClassTextBox
            // 
            this.itemClassTextBox.Location = new System.Drawing.Point(275, 112);
            this.itemClassTextBox.Name = "itemClassTextBox";
            this.itemClassTextBox.Size = new System.Drawing.Size(100, 22);
            this.itemClassTextBox.TabIndex = 3;
            this.itemClassTextBox.Leave += new System.EventHandler(this.itemClassTextBox_Leave);
            // 
            // unitsOnHandTextBox
            // 
            this.unitsOnHandTextBox.Location = new System.Drawing.Point(275, 153);
            this.unitsOnHandTextBox.Name = "unitsOnHandTextBox";
            this.unitsOnHandTextBox.Size = new System.Drawing.Size(100, 22);
            this.unitsOnHandTextBox.TabIndex = 4;
            this.unitsOnHandTextBox.Leave += new System.EventHandler(this.unitsOnHandTextBox_Leave);
            // 
            // unitCostTextBox
            // 
            this.unitCostTextBox.Location = new System.Drawing.Point(275, 196);
            this.unitCostTextBox.Name = "unitCostTextBox";
            this.unitCostTextBox.Size = new System.Drawing.Size(100, 22);
            this.unitCostTextBox.TabIndex = 5;
            this.unitCostTextBox.Leave += new System.EventHandler(this.unitCostTextBox_Leave);
            // 
            // totalInventoryCostTextBox
            // 
            this.totalInventoryCostTextBox.Enabled = false;
            this.totalInventoryCostTextBox.Location = new System.Drawing.Point(275, 240);
            this.totalInventoryCostTextBox.Name = "totalInventoryCostTextBox";
            this.totalInventoryCostTextBox.Size = new System.Drawing.Size(100, 22);
            this.totalInventoryCostTextBox.TabIndex = 6;
            // 
            // dailyUsageTextBox
            // 
            this.dailyUsageTextBox.Location = new System.Drawing.Point(275, 283);
            this.dailyUsageTextBox.Name = "dailyUsageTextBox";
            this.dailyUsageTextBox.Size = new System.Drawing.Size(100, 22);
            this.dailyUsageTextBox.TabIndex = 7;
            this.dailyUsageTextBox.Leave += new System.EventHandler(this.dailyUsageTextBox_Leave);
            // 
            // yearlyUsageTextBox
            // 
            this.yearlyUsageTextBox.Enabled = false;
            this.yearlyUsageTextBox.Location = new System.Drawing.Point(275, 328);
            this.yearlyUsageTextBox.Name = "yearlyUsageTextBox";
            this.yearlyUsageTextBox.Size = new System.Drawing.Size(100, 22);
            this.yearlyUsageTextBox.TabIndex = 8;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(492, 100);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(181, 162);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 12;
            this.pictureBox1.TabStop = false;
            // 
            // PartsEntry
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.yearlyUsageTextBox);
            this.Controls.Add(this.dailyUsageTextBox);
            this.Controls.Add(this.totalInventoryCostTextBox);
            this.Controls.Add(this.unitCostTextBox);
            this.Controls.Add(this.unitsOnHandTextBox);
            this.Controls.Add(this.itemClassTextBox);
            this.Controls.Add(this.partDescriptionTextBox);
            this.Controls.Add(this.partNumberTextBox);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.clearButton);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.submitButton);
            this.Name = "PartsEntry";
            this.Text = "Parts Entry";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button submitButton;
        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.Button clearButton;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox partNumberTextBox;
        private System.Windows.Forms.TextBox partDescriptionTextBox;
        private System.Windows.Forms.TextBox itemClassTextBox;
        private System.Windows.Forms.TextBox unitsOnHandTextBox;
        private System.Windows.Forms.TextBox unitCostTextBox;
        private System.Windows.Forms.TextBox totalInventoryCostTextBox;
        private System.Windows.Forms.TextBox dailyUsageTextBox;
        private System.Windows.Forms.TextBox yearlyUsageTextBox;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}

