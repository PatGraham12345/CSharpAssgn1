﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace assignment2
{
    public partial class PartsEntry : Form
    {
        public PartsEntry()
        {
            InitializeComponent();

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }



        private void partNumberTextBox_Leave(object sender, EventArgs e)
        {
            string partNumber = partNumberTextBox.Text;
            int partNumberLength = partNumber.Length;

            
            if (partNumberLength == 0)
            {
                MessageBox.Show("Please enter a valid part number.");
                partNumberTextBox.Focus();
            }

        }

        private void partDescriptionTextBox_Leave(object sender, EventArgs e)
        {
            string partDescription = partDescriptionTextBox.Text;
            int partDescriptionLength = partDescription.Length;

            
            if (partDescriptionLength == 0)
            {
                MessageBox.Show("Please enter a valid part description.");
                partDescriptionTextBox.Focus();

            }

        }

        private void itemClassTextBox_Leave(object sender, EventArgs e)
        {
            string itemClassText = itemClassTextBox.Text;
            if (itemClassText != "A" && itemClassText != "P" && itemClassText != "T")
            {
                MessageBox.Show("Please enter a valid value for item class.");
                itemClassTextBox.Focus();
            }
        }

        private void unitsOnHandTextBox_Leave(object sender, EventArgs e)
        {
            string unitsOnHandString = unitsOnHandTextBox.Text;
            bool validNum = double.TryParse(unitsOnHandTextBox.Text, out double unitsOnHand);
            if (unitsOnHand < 0 || !(validNum))
            {
                MessageBox.Show("Please enter a valid positive number for the units on hand.");
                unitsOnHandTextBox.Focus();

            }
        }

        private void unitCostTextBox_Leave(object sender, EventArgs e)
        {
            string unitCostString = unitCostTextBox.Text;
            bool validUnitsOnHand = double.TryParse(unitsOnHandTextBox.Text, out double unitsOnHand);
            bool validUnitCost = double.TryParse(unitCostTextBox.Text, out double unitCost);
            if (unitCost < 0 || !(validUnitsOnHand) || !(validUnitCost))
            {
                MessageBox.Show("Please enter a valid price for the unit cost.");
                unitCostTextBox.Focus();
            }
            else
            {
                double totalInventoryCost = unitCost * unitsOnHand;
                string totalInventoryCostString = totalInventoryCost.ToString("C");
                totalInventoryCostTextBox.Text = totalInventoryCostString;
            }

        }

        private void dailyUsageTextBox_Leave(object sender, EventArgs e)
        {
            bool validDouble = double.TryParse(dailyUsageTextBox.Text, out double dailyUsage);
            if (dailyUsage < 0 || !(validDouble))
            {

                MessageBox.Show("Please enter a valid number for the daily usage.");
                dailyUsageTextBox.Text = "";
                dailyUsageTextBox.Focus();
            }
            else
            {
                bool leapYear = DateTime.IsLeapYear(DateTime.Now.Year);
                if (leapYear)
                {
                    int numberOfDays = 366;
                    double yearlyUsage = dailyUsage * numberOfDays;
                    yearlyUsageTextBox.Text = yearlyUsage.ToString();
                }
                else
                {
                    int numberOfDays = 365;
                    double yearlyUsage = dailyUsage * numberOfDays;
                    yearlyUsageTextBox.Text = yearlyUsage.ToString();
                }
            }

        }




        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        private void clearButton_Click(object sender, EventArgs e)
        {
            partNumberTextBox.Text = "";
            partDescriptionTextBox.Text = "";
            itemClassTextBox.Text = "";
            unitsOnHandTextBox.Text = "";
            unitCostTextBox.Text = "";
            totalInventoryCostTextBox.Text = "";
            dailyUsageTextBox.Text = "";
            yearlyUsageTextBox.Text = "";
            partNumberTextBox.Focus();



        }
        private void submitButton_Click(object sender, EventArgs e)
        {
            MessageBox.Show
                (
                "Part Number: " + partNumberTextBox.Text 
                + "\nPart Description: " + partDescriptionTextBox.Text
                + "\nItem Class: " + itemClassTextBox.Text
                + "\nUnits On Hand: " + unitsOnHandTextBox.Text
                + "\nUnit Cost: " + unitCostTextBox.Text
                + "\nTotal Inventory Cost: " + totalInventoryCostTextBox.Text
                + "\nDaily Usage: " + dailyUsageTextBox.Text
                + "\nYearly Usage: " + yearlyUsageTextBox.Text
                );



        }
    }
}
